/** Automatically generated file. DO NOT MODIFY */
package ds.zillowpayment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}